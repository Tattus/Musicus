
SDL_image:  An example image loading library for use with SDL
Copyright (C) 1997-2013 Sam Lantinga <slouken@libsdl.org>

https://www.libsdl.org/projects/SDL_image/

This library is distributed under the terms of the zlib license:
http://www.zlib.net/zlib_license.html

