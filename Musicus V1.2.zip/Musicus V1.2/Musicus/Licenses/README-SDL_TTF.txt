
SDL_ttf:  A companion library to SDL for working with TrueType (tm) fonts
Copyright (C) 1997-2013 Sam Lantinga <slouken@libsdl.org>

https://www.libsdl.org/projects/SDL_ttf/

Portions of this software are copyright © 2013 The FreeType Project (www.freetype.org).  All rights reserved.
	http://www.freetype.org/

This library is distributed under the terms of the zlib license:
http://www.zlib.net/zlib_license.html

